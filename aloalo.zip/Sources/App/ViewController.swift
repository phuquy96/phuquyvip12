import UIKit
import WebKit

class ViewController: UIViewController {

    private var webView: WKWebView!
    private let session = URLSession.shared

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }
    override var prefersStatusBarHidden: Bool { false }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.black
        setupWebView()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        webView.frame = view.bounds
    }

    private func setupWebView() {
        let ucc = WKUserContentController()
        ucc.add(self, name: "nativeBridge")

        let cfg = WKWebViewConfiguration()
        cfg.userContentController = ucc
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []

        let wpp = WKWebpagePreferences()
        wpp.allowsContentJavaScript = true
        cfg.defaultWebpagePreferences = wpp

        webView = WKWebView(frame: view.bounds, configuration: cfg)
        webView.backgroundColor = UIColor.black
        webView.isOpaque = false
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.bounces = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.navigationDelegate = self
        view.addSubview(webView)

        // Load HTML directly from embedded AppHTML to guarantee instant and reliable display
        let htmlString = AppHTML.content
        webView.loadHTMLString(htmlString, baseURL: Bundle.main.bundleURL)
    }
}

// MARK: - Navigation Delegate
extension ViewController: WKNavigationDelegate {
    func webView(_ webView: WKWebView,
                 decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        // Only open external browser if user explicitly clicked an external link (like Telegram/Support)
        if action.navigationType == .linkActivated {
            if let url = action.request.url, url.scheme == "http" || url.scheme == "https" {
                UIApplication.shared.open(url)
            }
            decisionHandler(.cancel)
            return
        }
        // Always allow internal UI loading
        decisionHandler(.allow)
    }
}

// MARK: - Native Bridge
extension ViewController: WKScriptMessageHandler {
    func userContentController(_ ucc: WKUserContentController,
                                didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any],
              let action = body["action"] as? String else { return }

        switch action {

        case "getHWID":
            let raw = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
            let hwid = "PQ-" + raw.replacingOccurrences(of: "-", with: "")
                                  .prefix(8).uppercased()
            DispatchQueue.main.async {
                self.eval("window.receiveNativeHWID('\(hwid)')")
            }

        case "httpGet":
            guard let urlStr = body["url"] as? String,
                  let cbId  = body["callbackId"] as? String,
                  let url   = URL(string: urlStr) else { return }

            var req = URLRequest(url: url, timeoutInterval: 15)
            req.setValue("application/json", forHTTPHeaderField: "Accept")

            session.dataTask(with: req) { [weak self] data, _, error in
                DispatchQueue.main.async {
                    if let data = data,
                       let str = String(data: data, encoding: .utf8) {
                        let safe = str
                            .replacingOccurrences(of: "\\", with: "\\\\")
                            .replacingOccurrences(of: "'",  with: "\\'")
                            .replacingOccurrences(of: "\n", with: "\\n")
                            .replacingOccurrences(of: "\r", with: "")
                        self?.eval("window.receiveAPIResponse('\(cbId)','\(safe)')")
                    } else {
                        let err = error?.localizedDescription ?? "Network error"
                        self?.eval("if(window['\(cbId)_e'])window['\(cbId)_e']('\(err)')")
                    }
                }
            }.resume()

        case "openURL":
            if let urlStr = body["url"] as? String,
               let url = URL(string: urlStr) {
                DispatchQueue.main.async {
                    UIApplication.shared.open(url)
                }
            }

        case "launchApp":
            // Placeholder: handle in-app launch logic
            break

        default:
            break
        }
    }

    private func eval(_ js: String) {
        webView.evaluateJavaScript(js, completionHandler: nil)
    }
}
